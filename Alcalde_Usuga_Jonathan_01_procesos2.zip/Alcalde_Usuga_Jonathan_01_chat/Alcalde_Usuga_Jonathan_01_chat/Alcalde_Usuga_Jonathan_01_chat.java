package Alcalde_Usuga_Jonathan_01_chat;

import java.util.Scanner;

public class Alcalde_Usuga_Jonathan_01_chat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner teclado = new Scanner(System.in);
		String maniobra ="";
		System.out.println("Escribe el nombre de usuario");
		maniobra = teclado.nextLine(); 
		Thread servidor = new Servidor();
        Thread cliente = new Cliente(maniobra);
        */
		Servidor servidor = new Servidor();
		Cliente cliente =  new Cliente();
		servidor.run();
        cliente.run();
	}

}
