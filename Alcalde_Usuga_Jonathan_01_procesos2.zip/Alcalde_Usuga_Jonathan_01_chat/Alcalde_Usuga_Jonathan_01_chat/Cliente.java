package Alcalde_Usuga_Jonathan_01_chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente implements Runnable {
	private Socket cliente;
	private BufferedReader in;
	private PrintWriter out;
	private boolean hecho;

	
	@Override
	public void run() {
		try {
			Socket cliente = new Socket("127.0.0.1",9999);
			out = new PrintWriter(cliente.getOutputStream(),true);
			in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
			
			Scanner teclado = new Scanner(System.in);
			System.out.println("Escribe tu nombre de usuario");
			String usuario = teclado.nextLine();
			Thread t = new Thread(usuario);
			t.start();
			
			String inMensaje;
			while((inMensaje = in.readLine()) != null) {
				System.out.println(inMensaje);
			}
			teclado.close();
			cerrarConexion();
		}
		catch(IOException e) {
			cerrarConexion();
			
		}
    }
	
	public void cerrarConexion() {
		hecho  = true;
		try {
			in.close();
			out.close();
			if(!cliente.isClosed()) {
				cliente.close();
			}
		}
		catch(IOException e) {
			//No se puede manejar la excepcion
		}
		
		
	}
	class ManejadorDeInputs implements Runnable{
		@Override
		public void run() {
			try {
				BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
				while(!hecho) {
					if(!hecho) {
						String mensaje = lector.readLine();
						if(mensaje.equals("/quit")) {
							lector.close();
							cerrarConexion();
						}
						else {
							out.println(mensaje);
						}
					}
					
				}
			} catch(IOException e) {
				cerrarConexion();
			}
		}
	}
	public static void main(String[] args) {
		Cliente cliente = new Cliente();
		cliente.run();
	}
	
}