Python 3.9.0 (tags/v3.9.0:9cf6752, Oct  5 2020, 15:34:40) [MSC v.1927 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============================== RESTART: D:/sge2.py =============================
Traceback (most recent call last):
  File "D:/sge2.py", line 8, in <module>
    uu = u.decode('utf8')
AttributeError: 'str' object has no attribute 'decode'
>>> 
============================== RESTART: D:/sge2.py =============================
Introduce la base del rectangulo: 18
Teclea la altura del rectangulo: 7
El perimetro es:  50
El area es:  126
>>> 