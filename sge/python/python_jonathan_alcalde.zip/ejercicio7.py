# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
#!/usr/bin/env python
#-*- coding: utf-8 -*-

#bucle for que se repite 50 en cada iteracion se suma el valor a una variable, al terminar el bucle se muestra el valor de la variable
f = 0
for i in range(1, 51):
    print(i)
    f = f + i
print ('El total es:',f)
