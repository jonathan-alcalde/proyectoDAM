# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

#bucle for que imprime los 25 números naturales
for i in range(1, 26):
    print(i)
