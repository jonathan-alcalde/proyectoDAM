# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

#bucle for que imprime los 25 primeros numeros si divididos entre 2 su resto no da 0 
for i in range(1, 26):
    if i % 2 != 0:
        print(i)
