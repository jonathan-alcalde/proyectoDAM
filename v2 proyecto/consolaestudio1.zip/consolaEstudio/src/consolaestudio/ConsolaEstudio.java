/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consolaestudio;

import cadestudio.CADESTUDIO;
import cadestudio.Estudio;
import cadestudio.ExcepcionEstudio;
import java.sql.SQLException;
import java.util.Scanner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author usuario
 */
public class ConsolaEstudio {
    /**
     * @param args the command line arguments
     */

        
    public static void main(String[] args) throws SQLException, ExcepcionEstudio {
        // TODO code application logic here
        /*Scanner teclado = new Scanner(System.in);
        int opcion = 0;
            ConsolaEstudio.menu();
            opcion = teclado.nextInt();
           switch (opcion){
            case 1:
                ConsolaEstudio.menuEstudio();
                break;
            case 2:
                ConsolaEstudio.menuVideojuego();
                break;
            case 9:
                System.out.println("Se termina el programa");
                teclado.close();
                System.exit(0);
                break;
            default:
                System.out.println("Error: el dato no coindice con ninguna de las opciones");
            }*/
            ConsolaEstudio.menu();
        
            
    }
    public static void menu() throws SQLException, ExcepcionEstudio   { 
            PropertyConfigurator.configure("maniobra\\log4j.properties");
            Logger logger = LogManager.getLogger("NAVEGACION");
            Scanner teclado = new Scanner(System.in);
            System.out.println("Menú Principal");
            System.out.println("---------------------");
            System.out.println("1-Gestión de Estudios");
            System.out.println("2-Gestión de Videojuegos");
            System.out.println("9-Salir");
            int opcion = teclado.nextInt();
        switch (opcion){
            case 1:
                logger = LogManager.getLogger("NAVEGACION");
                logger.trace("Ha entrado en la Gestión de Estudios");
                ConsolaEstudio.menuEstudio();
                break;
            case 2:
                logger = LogManager.getLogger("NAVEGACION");
                logger.trace("Ha entrado en la Gestión de Videojuegos");
                 ConsolaEstudio.menuVideojuego();
                break;
            case 9:
                logger = LogManager.getLogger("NAVEGACION");
                logger.trace("Ha salido del programa");
                System.out.println("El programa se termina");
                teclado.close();
                System.exit(0);
                break;
            default:
                logger = LogManager.getLogger("NAVEGACION");
                logger.trace("Ha introducido una opción incorrecta en el menu principal" + opcion);
                System.out.println("Error: el dato no coindice con ninguna de las opciones");
                ConsolaEstudio.menu();
            } 
           }
       
    
    public static void menuEstudio() throws SQLException, ExcepcionEstudio{
        PropertyConfigurator.configure("maniobra\\log4j.properties");
        Logger logger = LogManager.getLogger("NAVEGACION");
        Scanner teclado = new Scanner(System.in);
        CADESTUDIO cad = new CADESTUDIO();
       // Estudio s = new Estudio();
        System.out.println("Gestión de Estudios");
        System.out.println("-------------------");
        System.out.println("1-Nuevo Estudio");
        System.out.println("2-Eliminar Estudio");
        System.out.println("3-Actualizar Estudio");
        System.out.println("4-Ver 1 Estudio");
        System.out.println("5-Ver todos los estudios");
        System.out.println("9-Salir");
        int opcion = teclado.nextInt();
        switch (opcion){
            case 1:
                logger.trace("Ha entrado en la opción de crear Estudio");
                Estudio s = new Estudio();
                System.out.println("Escribe el nombre del nuevo Estudio");
                String nombre_nuevo_estudio = teclado.nextLine();
                s.setNombre_estudio(nombre_nuevo_estudio); 
                System.out.println("Escribe el email del estudio ");
                String email_nuevo_estudio = teclado.nextLine(); 
                s.setEmail(email_nuevo_estudio);
                try{
                    cad.insertarEstudio(s);
                    logger.trace("Ha insertado un estudio con éxito");
                    System.out.println("Inserción realizada correctamente");
                }
                catch(ExcepcionEstudio ex){
                    System.out.println(ex.getMensajeErrorUsuario());
                    logger = LogManager.getLogger("ERROR");
                    logger.error("Sentencia: " + ex.getSentenciaSQL() + " - Código Error: " + ex.getCodigoError() + " - Mensaje Error: " + ex.getMensajeErrorBD());
                }
                ConsolaEstudio.menuEstudio();
                break;
            case 2:
                logger.trace("Ha entrado en la opción de eliminar Estudio");
                System.out.println("Escribe el id del estudio que quieras eliminar");
                int eliminar_id =  teclado.nextInt();
                try{
                    cad.eliminarEstudio(eliminar_id);
                    logger.trace("Eliminación del estudio realizada correctamente" );
                    System.out.println("Eliminación realizada correctamente");
                }catch(ExcepcionEstudio ex){
                    System.out.println(ex.getMensajeErrorUsuario());
                    logger = LogManager.getLogger("ERROR");
                    logger.error("Sentencia: " + ex.getSentenciaSQL() + " - Código Error: " + ex.getCodigoError() + " - Mensaje Error: " + ex.getMensajeErrorBD());
                }
                ConsolaEstudio.menuEstudio();
                break;
            case 3:
                logger.trace("Ha entrado en la opción de modificar Estudio");
                s = new Estudio();
                System.out.println("Escribe el id del estudio que quieras actualizar");
                int id_estudio = teclado.nextInt();
                s.setEstudio_id(id_estudio);
                System.out.println("Escribe el nuevo nombre del estudio");
                String nombre_estudio = teclado.nextLine();
                s.setNombre_estudio(nombre_estudio);
                System.out.println("Escribe el nuevo email del estudio");
                String email_estudio = teclado.nextLine();
                s.setEmail(email_estudio);
                
                try{
                    cad.actualizarEstudio(s);
                    logger.trace("Actualización del estudio");
                    System.out.println("Actualización exitosa");
                }
                catch(ExcepcionEstudio ex){
                    System.out.println(ex.getMensajeErrorUsuario());
                    logger = LogManager.getLogger("ERROR");
                    logger.error("Sentencia: " + ex.getSentenciaSQL() + " - Código Error: " + ex.getCodigoError() + " - Mensaje Error: " + ex.getMensajeErrorBD());
                }
                ConsolaEstudio.menuEstudio();
                break;
            case 4:
                logger.trace("Ha entrado en la opción de leer 1 estudio");               System.out.println("Escribe el id del estudio");
                int id = teclado.nextInt();
                cad.leer1estudio(id);
                ConsolaEstudio.menuEstudio();
                break;
               case 5:
                logger.trace("Ha entrado en la opción de leer todos los estudios");
                cad.leerEstudios();
                ConsolaEstudio.menuEstudio();
                break;
            case 9:
                logger.trace("Ha entrado vuelto al menu principal");
                 ConsolaEstudio.menu();
                break;
            default:
                logger.trace("Ha introducido una opción errónea en Estudio" + opcion);
                System.out.println("Error: el dato no coindice con ninguna de las opciones");
                ConsolaEstudio.menuEstudio();
            }  
}
        
        
    
    
    public static void menuVideojuego() throws SQLException, ExcepcionEstudio{
        PropertyConfigurator.configure("maniobra\\log4j.properties");
        Logger logger = LogManager.getLogger("NAVEGACION");
        Scanner teclado = new Scanner(System.in);
        System.out.println("Gestión de Videojuegos");
        System.out.println("-------------------");
        System.out.println("1-Nuevo Videojuego");
        System.out.println("2-Eliminar Videojuego");
        System.out.println("3-Actualizar Videojuego");
        System.out.println("4-Ver 1 Videojuego");
        System.out.println("5-Ver todos los videojuegos");
        System.out.println("9-Salir");
        int opcion = teclado.nextInt();
        switch (opcion){
            case 1:
                logger.trace("Ha entrado en la opción de insertar un nuevo Videojuego");
                ConsolaEstudio.menuVideojuego();
                break;
            case 2:
                logger.trace("Ha entrado en la opción de eliminar un Videojuego");
                ConsolaEstudio.menuVideojuego();
                break;
            case 3:
                logger.trace("Ha entrado en la opción de actualizar un Videojuego");
                ConsolaEstudio.menuVideojuego();
                break;
            case 4:
                logger.trace("Ha entrado en la opción de mostrar un Videojuego");
                ConsolaEstudio.menuVideojuego();
                break;
            case 5:
                logger.trace("Ha entrado en la opción de ver todos los Videojuegos");
                ConsolaEstudio.menuVideojuego();
                break;
            case 9:
                logger.trace("Ha vuelto al menu principal");
                 ConsolaEstudio.menu();
                break;
            default:
                logger.trace("Ha introducido una opción erronea");
                System.out.println("Error: el dato no coindice con ninguna de las opciones");
                ConsolaEstudio.menuVideojuego();
            }       
    }
}
