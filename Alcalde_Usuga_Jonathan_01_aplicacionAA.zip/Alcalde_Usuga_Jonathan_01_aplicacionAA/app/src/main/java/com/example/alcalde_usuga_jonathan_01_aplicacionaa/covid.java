package com.example.alcalde_usuga_jonathan_01_aplicacionaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class covid extends AppCompatActivity {
    VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid);

        Button boton_inicio = findViewById(R.id.boton_inicio);
        boton_inicio.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent volver_inicio = new Intent(covid.this,MainActivity.class);
                startActivity(volver_inicio);
                Toast.makeText(covid.this,R.string.mensaje5,Toast.LENGTH_SHORT).show();
            }

        });
        videoView = (VideoView) findViewById(R.id.videoView);
        Uri uri = Uri.parse("https://www.youtube.com/watch?v=mgxDyrEnnoE");
        videoView.setMediaController((new MediaController(this)));
        videoView.setVideoURI(uri);
        videoView.requestFocus();
        videoView.start();
    }
}