package com.example.alcalde_usuga_jonathan_01_aplicacionaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class cursos extends AppCompatActivity {
    private static final String URL_INTERNET ="https://cdn.discordapp.com/attachments/388856772556881953/914290172848402482/unknown.png";
    private static final String URL_INTERNET_PICASSO ="http://i.imgur.com/DvpvklR.png";

    private ImageView imagenInternet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cursos);

        Button boton_inicio = findViewById(R.id.boton_inicio);
        boton_inicio.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent volver_inicio = new Intent(cursos.this,MainActivity.class);
                startActivity(volver_inicio);
                Toast.makeText(cursos.this,R.string.mensaje5,Toast.LENGTH_SHORT).show();
            }

        });

        setUpView();

        loadImageByInternetUrlWithPicasso();
        /*Picasso.with(this).load("http://servidor.com/imagen.jpg").into(imagenInternet);*/
    }
    private  void setUpView(){
        imagenInternet = findViewById(R.id.imageView);
    }

    private void loadImageByInternetUrlWithPicasso(){
        Picasso.with(this)
                .load(URL_INTERNET)
                .into(imagenInternet);
    }

}