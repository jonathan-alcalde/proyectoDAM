package com.example.alcalde_usuga_jonathan_01_aplicacionaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity<boton_inicio> extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button boton_inicio = findViewById(R.id.boton_inicio);
        boton_inicio.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent iniciar = new Intent(MainActivity.this,inicio.class);
                startActivity(iniciar);
                Toast.makeText(MainActivity.this,R.string.mensaje1,Toast.LENGTH_SHORT).show();
            }

            });
        Button boton_llamada = findViewById(R.id.boton_llamada);
        boton_llamada.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                Intent llamar = new Intent(Intent.ACTION_DIAL);
                llamar.setData(Uri.parse("tel:" + 942860637));
                if (llamar.resolveActivity(getPackageManager()) != null) {
                    startActivity(llamar);
                }
            }

        });

        /*public void dialPhoneNumber(String 942860637) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + 942860637));
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }*/
    }

}