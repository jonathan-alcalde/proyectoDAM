package com.example.alcalde_usuga_jonathan_01_aplicacionaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class inicio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        Button btnnoticias = findViewById(R.id.boton_noticias);
        btnnoticias.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent cursos = new Intent(inicio.this, cursos.class);
                startActivity(cursos);
                Toast.makeText(inicio.this,R.string.mensaje2,Toast.LENGTH_SHORT).show();
            }
        });
        Button btncontacto= findViewById(R.id.boton_contacto);
        btncontacto.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent contacto = new Intent(inicio.this,contacto.class);
                startActivity(contacto);
                Toast.makeText(inicio.this,R.string.mensaje3,Toast.LENGTH_SHORT).show();
            }
        });
        Button btncovid= findViewById(R.id.boton_covid);
        btncovid.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent covid = new Intent(inicio.this,covid.class);
                startActivity(covid);
                Toast.makeText(inicio.this,R.string.mensaje4,Toast.LENGTH_SHORT).show();
            }
        });
        Button btnpag_inicio= findViewById(R.id.boton_pag_inicio);
        btnpag_inicio.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent volver_inicio = new Intent(inicio.this,MainActivity.class);
                startActivity(volver_inicio);
                Toast.makeText(inicio.this,R.string.mensaje5,Toast.LENGTH_SHORT).show();
            }

        });


    }
}