package examenpspejer2;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class examenpspejer2 {

	public static void main(String[] args) throws InterruptedException {
		Runtime r = Runtime.getRuntime();
		ProcessBuilder pb = new ProcessBuilder("cmd","/c","C:\\Windows\\system32\\notepad.exe");
		File salida = new File("\\scripts\\salida.txt");
		try {        
			System.out.println("Lanzando el bloc de notas");
			pb.start();
	        
	       
	        
		}catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
		
		try {
			System.out.println("Lanzando el compilador de java");
			pb = new ProcessBuilder("cmd","/C","java -version","c:\\"); 
            pb.start();
            pb.redirectOutput(salida);
        } catch (IOException ex) {
                System.out.println("ERROR en la ejecuci�n");
        }
        
	}

}
