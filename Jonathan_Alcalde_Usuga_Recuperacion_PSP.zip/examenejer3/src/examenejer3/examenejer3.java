package examenejer3;

public class examenejer3 {

	public static void main(String[] args) {
		Thread servidor = new Servidor();
        Thread cliente = new Cliente("PEPE");
        
        servidor.start();
        cliente.start();
        
        Operador operador = new Operador(3,4,'+');
      	
        operador.setResultado(operador.getOperando() + operador.getOperador() + operador.getOperando2());	
        System.out.println(operador.resultado);
	}

}
