package examenejer3;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Cliente extends Thread {
    
    String nombre;
    
    public Cliente(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * M�todo que implementa el comportamiento del hilo
    */
    @Override
    public void run() {
        try {
            System.out.println("\t Cliente.Consola " + nombre + " - Se abre un socket en el cliente, y dicho socket establece "
                    + "una conexi�n con el socket del servidor situado en el puerto 30500 de la 127.0.0.1");
            String equipoServidor = "127.0.0.1";
            int puertoServidor = 30500;
            Socket socketCliente = new Socket(equipoServidor, puertoServidor);
            gestionarComunicacion(socketCliente);
            
            socketCliente.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    /**
     * M�todo que implementa el di�logo con el cliente
     * @param socketCliente Socket que se usa para realizar la comunicaci�n con el servidor
    */
    public void gestionarComunicacion (Socket socketCliente) {
        Operador operador = new Operador(3,4,'+');
        System.out.println("\t Cliente.Consola " + nombre + " - El cliente construye el objeto " + operador.toString());
        try {
            System.out.println("\t Cliente.Consola " + nombre + " - El cliente env�a el objeto al servidor");
            ObjectOutputStream oos = new ObjectOutputStream(socketCliente.getOutputStream());
            oos.writeObject(operador);
            System.out.println("\t Cliente.Consola " + nombre + " - El cliente ha recibido un objeto del servidor");
            ObjectInputStream ois = new ObjectInputStream(socketCliente.getInputStream());
            operador = (Operador) ois.readObject();
            System.out.println("\t Cliente.Consola " + nombre + " - Objeto recibido del Servidor: " + operador.toString());
            ois.close();
            oos.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
