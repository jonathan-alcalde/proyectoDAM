package examenejer3;

import java.io.Serializable;

public class Operador implements Serializable {
	int operando;
	int operando2;
	char operador;
	int resultado;
	public Operador() {
		
	}
	
	public Operador(int operando, int operando2, char operador) {
		this.operando = operando;
		this.operando2 = operando2;
		this.operador = operador;
	}
	public int getOperando() {
		return operando;
	}
	public void setOperando(int operando) {
		this.operando = operando;
	}
	public int getOperando2() {
		return operando2;
	}
	public void setOperando2(int operando2) {
		this.operando2 = operando2;
	}
	public char getOperador() {
		return operador;
	}
	public void setOperador(char operador) {
		this.operador = operador;
	}
	public int getResultado() {
		return resultado;
	}
	public void setResultado(int resultado) {
		this.resultado = resultado;
	}
	
	@Override
    public String toString() {
        return operando + " " + operador + " " + operando2 + " = " + resultado + "";
    }

}
	
	
	

