package examenejer3;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor extends Thread{
    /**
     * M�todo que implementa el comportamiento del hilo
    */
    @Override
    public void run() {
        try {
            System.out.println("Servidor.Consola - Se abre un socket servidor en el puerto 30500 de la m�quina local");
            int puertoServidor = 30500;
            ServerSocket socketServidor = new ServerSocket(puertoServidor);
            
            System.out.println("Servidor.Consola - El servidor se queda a la espera de alg�n cliente establezca conexi�n con el servidor");
            Socket clienteConectado = socketServidor.accept();
            gestionarDialogo(clienteConectado);
            
            clienteConectado.close();
            socketServidor.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    /**
     * M�todo que implementa el di�logo con el cliente
     * @param clienteConectado Socket que se usa para realizar la comunicaci�n con el cliente
    */
    public void gestionarDialogo(Socket clienteConectado) {
        try {
            System.out.println("Servidor.Consola - El servidor recibe un objeto Operador del cliente");
            ObjectInputStream ois = new ObjectInputStream(clienteConectado.getInputStream());
            Operador operador = (Operador) ois.readObject();
            System.out.println("Servidor.Consola - Objeto recibido del Cliente: " + operador.toString());
            
            System.out.println("Servidor.Consola - El servidor responde al cliente con el mismo objeto resolviendo la operacion");
            operador.setResultado(operador.getOperando() + operador.getOperador() + operador.getOperando2());
            ObjectOutputStream oos = new ObjectOutputStream(clienteConectado.getOutputStream());
            oos.writeObject(operador);
            
            ois.close();
            oos.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
