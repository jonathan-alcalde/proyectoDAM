package examenpspejer1;

public class examenpspejer1 {

	public static void main(String[] args) {
		//Se instancian los hilos
		Batel b1 = new Batel("Castro", 7 , null); // el primer hilo
		Batel b2 = new Batel("La Marinera",4,b1);
		Batel b3 = new Batel("Orio",8,b2);
		Batel b4 = new Batel("Kaiuku",5,b3);
		
		//Se inician los hilos
		b4.run();
		b3.run();
		b2.run();
		b1.run();
	
	}

}
