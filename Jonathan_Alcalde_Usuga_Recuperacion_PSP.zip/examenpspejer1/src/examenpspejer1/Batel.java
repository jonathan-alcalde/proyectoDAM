package examenpspejer1;

public class Batel extends Thread{
	String nombre;
	int tiempo;
	Batel siguiente;
	
	public Batel() {
		
	}
	
	public Batel(String nombre, int tiempo, Batel siguiente) {
	this.nombre = nombre;
	this.tiempo = tiempo;
	this.siguiente = siguiente;
	}
	
	//Si un batel tiene algun batel previo no se iniciar� hasta que el anterior termine
	public void run() {
		if (siguiente != null) {
            siguiente.run();
        }
        try {
         //Muestra la informacion del hilo  
           while(tiempo != 0) {
        	System.out.println("[Soy el batel " + nombre + " con id " + this.getId() + " con nombre " + this.getName()  + " mi prioridad es " + this.getPriority()+ "  ]");
        		Thread.sleep(1000);
        		tiempo = tiempo - 1;
        	
        		
           }
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
	}
}
