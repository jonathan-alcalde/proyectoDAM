<?php

$nom = $_POST[nombre];
$ape = $_POST[apellidos];
echo "El nombre recibido es: $nom, y ";
echo "los apellidos son: $ape ";
?> 
