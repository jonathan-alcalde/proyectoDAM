package ejemplosut3;

import java.io.*;
import java.net.*;

public class ejemplo2Servidor {

    public static void main(String[] arg) throws IOException {
        int numeroPuerto = 6000;// Puerto
        ServerSocket servidor = new ServerSocket(numeroPuerto);
        String cad = "";

        System.out.println("Esperando conexion...");
        Socket clienteConectado = servidor.accept();
        System.out.println("Cliente conectado...");
        // CREO FLUJO DE SALIDA AL CLIENTE		
        PrintWriter fsalida = new PrintWriter(clienteConectado.getOutputStream(), true);
        // CREO FLUJO DE ENTRADA DEL CLIENTE		
        BufferedReader fentrada = new BufferedReader(new InputStreamReader(clienteConectado.getInputStream()));
        while ((cad = fentrada.readLine()) != null) {
            fsalida.println(cad); //envia datos al cliente
            System.out.println("Recibiendo: " + cad);
            if (cad.equals("*")) {
                break;
            }
        }
        // CERRAR STREAMS Y SOCKETS
        System.out.println("Cerrando conexion...");
        fentrada.close();
        fsalida.close();
        clienteConectado.close();
        servidor.close();
    }// main
}// fin
