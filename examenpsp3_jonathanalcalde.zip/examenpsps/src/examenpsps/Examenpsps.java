/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenpsps;

import static java.sql.DriverManager.println;
import java.util.Scanner;

/**
 *
 * @author DAM204
 */
public class Examenpsps implements Runnable{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String palabra;
        Scanner teclado = new Scanner(System.in);
        do
        {
        System.out.println("Introduce una palabra,debe de contener mas de una letra");
        palabra = teclado.nextLine();
        }while(palabra.length() <= 1);
        for(int i = 0; i < palabra.length(); i++){
            char letra = palabra.charAt(i);
            Hilo h1 = new Hilo(letra,500,0);
            h1.start();
            System.out.println(" ");
        }
    }
    
    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
        