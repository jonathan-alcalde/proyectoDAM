/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenpsps;

/**
 *
 * @author DAM204
 */
public class Hilo extends Thread{
    char nombre;
    int cont;
    int longitudPausa;
    Thread hiloPrevio;
    
    public Hilo(char nombre, int cont, int longitudPausa) {
        this.nombre = nombre;
        this.cont = cont;
        this.longitudPausa = longitudPausa;
        this.hiloPrevio = null;
        System.out.println("Creando el hilo " + nombre);
    }   
    public Hilo(char nombre, int cont, int longitudPausa, Thread hiloPrevio) {
        this.nombre = nombre;
        this.cont = cont;
        this.longitudPausa = longitudPausa;
        this.hiloPrevio = hiloPrevio;
        System.out.println("Creando el hilo " + nombre);
    }    

    
    @Override
    public void run() {
         while (cont >= 0) {
            System.out.print(nombre);
            cont = cont - 1;
        }
        System.out.println("");
        }
    }

