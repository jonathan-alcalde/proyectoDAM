public class ExcepcionNoVerificada extends RuntimeException {

    public ExcepcionNoVerificada (String mensaje) {
    	super(mensaje);
    }
}
