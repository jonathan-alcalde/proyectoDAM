package consulta_medica;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class consulta_medica {

	public static void main(String[] args) throws IOException {
		//Declaramos las variables e importamos la clase scanner
		Scanner teclado = new Scanner(System.in);
		String datos;
		char apoyo;
		
		
		//creamos el objeto paciente
		Paciente p1 = new Paciente();
		
		//Pedimos los datos
		System.out.println("Escribe tu nombre");
		datos = teclado.next();
		//comprobamos que el string solo tiene caracteres
		while (!datos.matches("[a-z].*"))
        {
            System.out.print("Dato erroneo. Introduce de nuevo el nombre: ");
            datos = teclado.nextLine();
        }
		p1.setNombre(datos);
		
		System.out.println("Escriba su DNI");
		datos = teclado.next();
		
		//creamos un objeto validadorDNI que comprobar� si el dni introducido es correcto
		ValidadorDNI v1 = new ValidadorDNI(datos);
		while (!v1.validar())
		{
			System.out.print("Dato erróneo. Introduce de nuevo el DNI: ");
            datos = teclado.nextLine();
            v1.setDni(datos);
		}
		p1.setDni(datos);
		
		
		System.out.print("Introduce cu�ntos hermanos tienes: ");
        datos = teclado.nextLine();
        //comprobamos que el dato introducido es un int positivo
        while (!esEntero(datos)) {
            System.out.print("Dato err�neo. Introduce de nuevo cu�ntos hermanos tienes: ");
            datos = teclado.nextLine();
        }
        p1.setnFamiliares(Integer.parseInt(datos));
        
        System.out.print("Introduce tu fecha de nacimiento (Formato dia-mes-a�o)");
        datos = teclado.nextLine();
        //comprobamos si la fecha de nacimiento tiene la estructura correcta
        while (!esFecha(datos)) {
        	System.out.print("Dato err�neo. Introduce tu fecha de nacimiento: ");
            datos = teclado.nextLine();
        }
        p1.setFechan(datos);
        
        System.out.println("�Cu�l es tu sexo?");
        datos = teclado.next();
        apoyo = datos.charAt(0);
        apoyo = Character.toUpperCase(apoyo);
        //compronamos que el caracter introducido es correcto
        while(apoyo != 'M' || apoyo != 'H') {
            System.out.print("Dato err�neo. Introduce un sexo v�lido: ");
            datos = teclado.nextLine();
            apoyo = datos.charAt(0);
            apoyo = Character.toUpperCase(apoyo);
        }
        p1.setSexo(apoyo);
        
        if(p1.sexo == 	'M')
        {
        	System.out.print("�Estas o has estado embarazada?");
            datos = teclado.nextLine();
            while(!datos.toLowerCase().equals("si") || !datos.toLowerCase().equals("no"))
            {
            	System.out.println("Dato err�neo. Introduce una respuesta v�lida");
            	 datos = teclado.nextLine();
            }
            	
            if(datos.equals("si")){
            	p1.setEmbarazada(true);
            	}
            else if(datos.equals("no")){
            	p1.setEmbarazada(false);
            	}    	
        }
        
        
	}   
	
		//metodo que comprueba que el dato introducido es un entero y es positivo
        public static boolean esEntero(String s) {
            try { 
            	int n1;
                 n1 = Integer.parseInt(s);
                 if(n1 >= 0) {
                	 
                 }
                 else {
                	 return false;
                 }
                
            } catch(NumberFormatException e) { 
                return false; 
            }
            return true;
        }
        
        //m�todo que comprueba la fecha introducido
        public static boolean esFecha(String s) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            try { 
                sdf.parse(s);
            } catch (ParseException e) {
                return false;
            }
            return true;
        }
	}	
		
