package consulta_medica;


public class Paciente {
	String dni;
	String fechan;
	String nombre;
	int nFamiliares;
	boolean embarazada;
	char sexo;
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getFechan() {
		return fechan;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setFechan(String fechan) {
		this.fechan = fechan;
	}
	public char getSexo() {
		return sexo;
	}
	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	public int getnFamiliares() {
		return nFamiliares;
	}
	public void setnFamiliares(int nFamiliares) {
		this.nFamiliares = nFamiliares;
	}
	public boolean isEmbarazada() {
		return embarazada;
	}
	public void setEmbarazada(boolean embarazada) {
		this.embarazada = embarazada;
	}
	public String getNombre() {
		return nombre;
	}
	public void setAlergias(String nombre) {
		this.nombre = nombre;
	}
}
